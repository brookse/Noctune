﻿#pragma strict

static var color;
var redSprite : Sprite;
var blueSprite : Sprite;

function Start () {
	
}

function Update () {
	transform.position.z = 0;
	transform.Translate(Vector3(0,-4,0) * Time.deltaTime);
}

function setColor(colorOnStart) {
	if(colorOnStart == Play_song.red){
		GetComponent(SpriteRenderer).sprite = redSprite;
		Button.correctColors.Push(Play_song.red);
		Debug.Log("Note : " + Play_song.red);
	} else if(colorOnStart == Play_song.blue){
		GetComponent(SpriteRenderer).sprite = blueSprite;
		Button.correctColors.Push(Play_song.blue);
		Debug.Log("Note : " + Play_song.blue);
	}
}