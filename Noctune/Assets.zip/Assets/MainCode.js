﻿#pragma strict

static var score = 0;
static var highScore = 0;
