﻿#pragma strict

var blueBar : Sprite;
var redBar : Sprite;

function Start () {

}

function Update () {
	
}

function OnGUI(){
	// check to see user's input
	if(Input.GetButton("left")){
		// if left is down, change to red
		GetComponent(SpriteRenderer).sprite = redBar;
		GetComponent(SpriteRenderer).enabled = true;
		Debug.Log("Space : " + Play_song.red);
		Button.currentColor = Play_song.red;
		
	} else if(Input.GetButton("right")){
		// if right is down, change to blue
		GetComponent(SpriteRenderer).sprite = blueBar;
		GetComponent(SpriteRenderer).enabled = true;
		Debug.Log("Space : " + Play_song.blue);
		Button.currentColor = Play_song.blue;
		
	} else if(!Input.GetButton("left") || !Input.GetButton("right")){
		// if nothing or both are down, just be green
		GetComponent(SpriteRenderer).enabled = false;
		Button.currentColor = Play_song.blank;
		Debug.Log("Space : " + Play_song.blank);
	}
}