﻿#pragma strict

var note : GameObject;
var whatpart : int = 0;
static final var red = "Red";
static final var blue = "Blue";
static final var blank = "Blank";
//static final pos : float = transform.position + Vector3(0,3.5,0);
//static final rot : float = Quaternion.Euler(0,0,0);

/*******************************************************************
*	Song to be played
*******************************************************************/
var music : AudioClip;

/*******************************************************************
*	Plays the song
*******************************************************************/
function Start () {
	
	audio.PlayOneShot(music, 0.7);
	
	if(whatpart <= 1){
		songStart();
		return;
	}
}

/*******************************************************************
*	Issues timed notes for song
*******************************************************************/
function songStart () {
	var note1 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script1 : Note = note1.GetComponent(Note);
	script1.setColor(red);
	yield WaitForSeconds (1);
	var note2 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script2 : Note = note2.GetComponent(Note);
	script2.setColor(red);
	yield WaitForSeconds (1);
	var note3 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script3 : Note = note3.GetComponent(Note);
	script3.setColor(red);
	yield WaitForSeconds (1);
	var note4 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script4 : Note = note4.GetComponent(Note);
	script4.setColor(red);
	yield WaitForSeconds (1);
	var note5 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script5 : Note = note5.GetComponent(Note);
	script5.setColor(red);
	yield WaitForSeconds (1);
	var note6 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script6 : Note = note6.GetComponent(Note);
	script6.setColor(blue);
	yield WaitForSeconds (1);
	var note7 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script7 : Note = note7.GetComponent(Note);
	script7.setColor(blue);
	yield WaitForSeconds (1);
	var note8 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script8 : Note = note8.GetComponent(Note);
	script8.setColor(blue);
	yield WaitForSeconds (1);
	var note9 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script9 : Note = note9.GetComponent(Note);
	script9.setColor(blue);
	yield WaitForSeconds (1);
	var note10 = Instantiate(note, transform.position + Vector3(0,3.5,0), Quaternion.Euler(0,0,0));
	var script10 : Note = note1.GetComponent(Note);
	script10.setColor(blue);
	yield WaitForSeconds (1);
	
	whatpart+=1;
	return;
}