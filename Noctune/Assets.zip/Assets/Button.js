﻿#pragma strict

/*******************************************************************
*	The object 
*******************************************************************/
var object: Transform;

/*******************************************************************
*	Variables for note color changes
*******************************************************************/
static var currentColor : String;
//static var correctColor : String;
static var correctColors = new Array();

/*******************************************************************
*	Variables needed for multiplier
*******************************************************************/
static var multiplier = 1.0;
static var lastScore = 0;
static var currentScore : int;
static var newScore : float;

/*******************************************************************
*	Constants for score values 
*******************************************************************/
static final var unbelievableScore = 500;
static final var perfectScore = 100;
static final var greatScore = 50;
static final var okayScore = 25;
static final var missScore = 0;

/*******************************************************************
*	Sets the object as spacebar
*******************************************************************/
function Start () {
	object = GameObject.Find("spacebar").transform;
}

/*******************************************************************
*	Figures out the score the user got per note that comes down.
*******************************************************************/
function Update () {
	// Verify the button pressed was space
	Debug.Log("CORRECT COLORS HERE UGH: " + correctColors);
	if(Input.GetButtonDown ("space")) {
		var correctColor : String = correctColors.Shift();
		var colorMatches : boolean = currentColor.Equals(correctColor);
			// Criteria for getting an Unbelievable, position and color
			if(transform.position.y == -4.16 && colorMatches){
				currentScore = unbelievableScore;
				calcScore();
				Score.currentScore += newScore;
				Score.howGood = "UNBELIEVABLE!";
				Score.numUnbelievable += 1;
				Destroy(gameObject);
				Debug.Log("Successful hit - Current: " + currentColor + " Correct: " + correctColor);
			// Criterion for getting a Perfect, position and color
			} else if(transform.position.y < -4.09 && transform.position.y > -4.23 && colorMatches){
				currentScore = perfectScore;
				calcScore();
				Score.currentScore += newScore;
				Score.howGood = "PERFECT!";
				Score.numPerfect += 1;
				Destroy(gameObject);
				Debug.Log("Successful hit - Current: " + currentColor + " Correct: " + correctColor);
			// Criterion for getting a Great, position and color
			} else if((transform.position.y < -3.95 && transform.position.y >= -4.09) || (transform.position.y <= -4.23 && transform.position.y > -4.37) && (colorMatches)){ 
				currentScore = greatScore;
				calcScore();
				Score.currentScore += newScore;
				Score.howGood = "Great!";
				Score.numGreat += 1;
				Destroy(gameObject);
				Debug.Log("Successful hit - Current: " + currentColor + " Correct: " + correctColor);
			// Criterion for getting an Okay, position and color
			} else if((transform.position.y < -3.81 && transform.position.y >= -3.95) || (transform.position.y <= -4.37 && transform.position.y > -4.51) && (colorMatches)){
				currentScore = okayScore;
				calcScore();
				Score.currentScore += newScore;
				Score.howGood = "Okay!";
				Score.numOkay += 1;
				Destroy(gameObject);
				Debug.Log("Successful hit - Current: " + currentColor + " Correct: " + correctColor);
			// Criterion for getting a Miss, position and color - will not register a miss before the spacebar object
			} else if(transform.position.y <= -4.51){
				currentScore = missScore;
				calcScore();
				Score.currentScore += newScore;
				Score.howGood = "Miss!";
				Score.numMiss += 1;
				Destroy(gameObject);
			} else {
				Debug.Log("NOTHINGISNVISFHSIGNSRG");
				currentScore = missScore;
			}
	}else {
		// Criterion for getting a miss when you don't click spacebar
		if(transform.position.y <= -4.51){
			currentScore = missScore;
			calcScore();
			Score.currentScore += newScore;
			Score.howGood = "Miss!";
			Score.numMiss += 1;
			Destroy(gameObject);
		}
	}
}

/*******************************************************************
*	Calculates the multiplier and new multiplied score
*		Will determine previous score and compare to current score
*		Replaces last score with current score
*		Calculates multiplier
*******************************************************************/
function calcScore() {
	if((lastScore == unbelievableScore || lastScore == perfectScore || lastScore == greatScore) && (currentScore == unbelievableScore || currentScore == perfectScore || currentScore == greatScore)){
		multiplier += .2;
	} else if((lastScore == unbelievableScore || lastScore == perfectScore || lastScore == greatScore) && (currentScore == okayScore || currentScore == missScore)) {
		multiplier = 1.0;
	}
	lastScore = currentScore;
	Score.multiplier = multiplier;
	newScore = currentScore * multiplier;
}