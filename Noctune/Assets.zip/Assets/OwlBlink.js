﻿#pragma strict

var eyeClosed : SpriteRenderer;
static var time : float;

static var randNum : int;

function Start () {
	eyeClosed.enabled = false;
	time = Random.Range(1,6);
}

function OnGUI(){
	// have open eye layer stagnant
	time -= Time.deltaTime;
	// yield for certain amount of time
	randNum = Random.Range(2,8);
//	yield WaitForSeconds(randNum);
	
	// close eye layer is higher than eye open for 1 second
	if(time <= 0){
		eyeClosed.enabled = !eyeClosed.enabled;
		if(eyeClosed.enabled){
			time = .75;
		} else {
			time = Random.Range(2,8);
		}
	}
}