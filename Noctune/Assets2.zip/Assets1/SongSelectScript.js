﻿
public var gt:GUIText;
public var bg:SpriteRenderer;
public var button:String;

var selected:boolean;

function OnMouseEnter()
{
	gt.color = Color.blue;
	bg.enabled = true;
	selected = true;
}

function OnMouseExit()
{
	gt.color = Color.white;
	bg.enabled = false;
	selected = false;
}

function Update() {
	if (Input.GetMouseButtonUp(0) && selected) {
		if (button==("Song Select")) {
			Debug.Log("Select Song");
//			Application.LoadLevel(Song1.unity);
		} else if (button==("Option Select")){
			Debug.Log("Options");
		}
	}
}