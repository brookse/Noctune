﻿
public var gt:GUIText;
public var bg:SpriteRenderer;

function OnMouseEnter()
{
	gt.color = Color.blue;
	bg.enabled = true;
}

function OnMouseExit()
{
	gt.color = Color.white;
	bg.enabled = false;
}

function OnClick()
{

}