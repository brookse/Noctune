Hello!

Thank you for grabbing Noctune from my repository.

Make sure the data folder and the executable are unzipped into the same folder.
To play, push the left and right buttons to match the color coming down the screen.

All rights, images, scripts and other data belong to Lyzzi Brooks (brookse@msoe.edu) and Amanda Marchetti (marchettia@msoe.edu). Please do not distribute on our own.